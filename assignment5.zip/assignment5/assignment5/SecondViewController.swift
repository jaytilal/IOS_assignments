//
//  SecondViewController.swift
//  assignment5
//
//  Created by Jayti Lal on 11/5/17.
//  Copyright © 2017 Jayti Lal. All rights reserved.
//

import UIKit
import Alamofire

class TableCell: UITableViewCell {
    @IBOutlet weak var Country: UILabel!
    @IBOutlet weak var Nickname: UILabel!
    @IBOutlet weak var State: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    @IBOutlet weak var Year: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}

class SecondViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UIPickerViewDataSource, UIPickerViewDelegate{
    
    var queue = DispatchQueue(label: "responseQueue", qos: .utility)
    var UserList = Array<User>()
    @IBOutlet weak var Search: UIButton!
    @IBOutlet weak var Year: UITextField!
    @IBOutlet weak var CountryPicker: UIPickerView!
    var selectedType = "Select Country"
    var selectedRow : Int = 0
    var SearchList = Array<User>()
    
    
    @IBOutlet weak var tableView: UITableView!
    var CountryList = Array<String>()
    
    @IBAction func Search(_ sender: UIButton) {
        if selectedType == "Select Country" &&  Year.text == "" {
            self.getSearchResults(url: "https://bismarck.sdsu.edu/hometown/users");
        }
       
        if (Year.text == "" ) && (selectedType != "Select Country"){
                self.getSearchResults(url: "http://bismarck.sdsu.edu/hometown/users?country=" + selectedType)
        }
        if (Year.text != "" ) && (selectedType != "Select Country"){
            self.getSearchResults(url: "https://bismarck.sdsu.edu/hometown/users?country=" + selectedType + "&year=" + Year.text!)
        }
        if (Year.text != "" ) && selectedType == "Select Country" {
            self.getSearchResults(url: "https://bismarck.sdsu.edu/hometown/users?year=" + Year.text!)
        }
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return UserList.count
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableCell
        cell.Nickname.text = UserList[indexPath.row].nickname
        cell.Country.text = UserList[indexPath.row].country
        cell.State.text = UserList[indexPath.row].state
        cell.Year.text = String(UserList[indexPath.row].year)
        cell.layer.borderColor = UIColor.darkGray.cgColor
        cell.layer.borderWidth = 1;
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int{
        return 1
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return CountryList.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return CountryList[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        guard (CountryList.count != 0) else { return }
        if component == 0 {
            selectedType = CountryList[row]
            print(selectedType)
        }
        selectedRow = row
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getCountries()
        self.CountryPicker.delegate = self
        self.CountryPicker.dataSource = self
        self.tableView.delegate = self
        self.tableView.dataSource = self
        getUsers()
    }
    
    func getSearchResults(url : String){
        Alamofire.request(url)
            .validate()
            .responseJSON { response in
                switch response.result {
                case .success:
                    if let Response = response.result.value {
                        self.UserList = [User]()
                        self.SearchList = [User]()
                        let res = Response as! NSArray
                        if res.count > 0{
                            for i in 0...res.count-1{
                                let jsonDictionary = res[i] as! NSDictionary
                                let user = User()
                                user.city = jsonDictionary["city"] as! String
                                user.country = jsonDictionary["country"] as! String
                                user.latitude = jsonDictionary["latitude"] as! Double
                                user.longitude = jsonDictionary["longitude"] as! Double
                                user.nickname = jsonDictionary["nickname"] as! String
                                user.state = jsonDictionary["state"] as! String
                                user.year = jsonDictionary["year"] as! Int
                                self.SearchList.append(user)
                            }
                            print(self.SearchList.count)
                        }
                          self.UserList = self.SearchList
                            self.tableView.reloadData()
                        
                    }
                case .failure(let error):
                    print(error)
                }
        }
    }
    
    
    func getCountries(){
        var array = Array<String>()
        self.CountryList.append("Select Country")
        Alamofire.request("https://bismarck.sdsu.edu/hometown/countries")
            .responseJSON{ response in
                if response.data != nil {
                    print("JSON: \(String(describing: response.result.value))")
                    array = (response.result.value as? Array<String>)!
                    for i in array{
                        self.CountryList.append(i)
                    }
                    
                    print(self.CountryList)
                    self.CountryPicker.reloadComponent(0)
                }
        }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getUsers(){
        Alamofire.request("https://bismarck.sdsu.edu/hometown/users")
            .validate()
            .responseJSON { response in
                switch response.result {
                case .success:
                    if let Response = response.result.value {
                        let res = Response as! NSArray
                        for i in 0...res.count-1{
                            let jsonDictionary = res[i] as! NSDictionary
                            let user = User()
                            user.city = jsonDictionary["city"] as! String
                            user.country = jsonDictionary["country"] as! String
                            user.latitude = jsonDictionary["latitude"] as! Double
                            user.longitude = jsonDictionary["longitude"] as! Double
                            user.nickname = jsonDictionary["nickname"] as! String
                            user.state = jsonDictionary["state"] as! String
                            user.year = jsonDictionary["year"] as! Int
                            self.UserList.append(user)
                           self.tableView.reloadData()
                        }
                        print(self.UserList.count)
                        
                    }
                case .failure(let error):
                    print(error)
                }
        }
    }
}

