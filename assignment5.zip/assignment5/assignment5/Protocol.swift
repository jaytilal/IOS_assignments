//
//  Protocol.swift
//  assignment5
//
//  Created by Jayti Lal on 11/8/17.
//  Copyright © 2017 Jayti Lal. All rights reserved.
//

import Foundation

protocol writeValueBackDelegate {
    func writeValueBack(Longitude: Double, Latitude : Double)
}
