//
//  AddUserViewController.swift
//  assignment5
//
//  Created by Jayti Lal on 11/5/17.
//  Copyright © 2017 Jayti Lal. All rights reserved.
//

import UIKit
import Alamofire
import MapKit
import CoreLocation

extension UIViewController {
    func showToast(message : String) {
        let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2-125, y: self.view.frame.size.height/2-75, width: 250, height: 150))
        toastLabel.backgroundColor = UIColor.darkGray
        toastLabel.textColor = UIColor.white
        toastLabel.textAlignment = .center;
        toastLabel.font = UIFont(name: "Calibri-Body", size: 12.0)
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10;
        toastLabel.clipsToBounds  =  true
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 4.0, delay: 0.0, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: {(isCompleted) in
            toastLabel.removeFromSuperview()
        })
    }
    
}


class AddUserViewController: UIViewController,UIPickerViewDataSource, UIPickerViewDelegate, SendDataToFormProtocol,UITextFieldDelegate{
    
    @IBOutlet weak var Nickname: UITextField!
    @IBOutlet weak var Password: UITextField!
    @IBOutlet weak var City: UITextField!
    @IBOutlet weak var Year: UITextField!
    @IBOutlet weak var Longitude: UITextField!
    @IBOutlet weak var Latitude: UITextField!
    @IBOutlet weak var pickerView: UIPickerView!
    
    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet var textFields: [UITextField]!
    
    @IBOutlet weak var ErrorMessage: UILabel!
    var CountryAndStates = Dictionary<String,Array<String>>()
    var CountryList:Array<String>?
    var StatesList:Array<String>?
    var selectedType:String?
    var selectedRow : Int = 0
    var queue = DispatchQueue(label: "responseQueue", qos: .utility)
    
    @IBAction func SetLocation(_ sender: UIButton) {
        print("Set Location")
    }
    
    func SendDataToForm(Longitude: Double, Latitude : Double) {
        self.Longitude.text = "\(Longitude)"
        self.Latitude.text = "\(Latitude)"
    }
    
    @IBAction func Submit(_ sender: UIButton) {
        if (Double(Longitude.text!)! == 0 || Longitude.text! == "") && (Double(Latitude.text!)! == 0 || Latitude.text! == ""){
            var address = selectedType! + " " + StatesList![selectedRow] + " " + City.text!
            geoCode(address: address, completionHandler: {(success) -> Void in
                if success{
                    print("success geocoding")
                    self.addUser()
                }
                else{
                    address = self.selectedType! + " " + self.StatesList![self.selectedRow]
                    self.geoCode(address: address, completionHandler: {(success) -> Void in
                        if success{
                            print("final geocoding")
                            self.addUser()
                        }
                    }
                    )
                }
            })
        }
        else{
            self.addUser()
        }
    }
    
    func addUser(){
        let year = Int(Year.text!)
        if year != nil{
            let parameters: Parameters = [
            "nickname" : Nickname.text!,
            "password" : Password.text!,
            "city" : City.text!,
            "longitude" : Double(Longitude.text!)!,
            "state" : StatesList![selectedRow],
            "year" : Int(Year.text!)!,
            "latitude" : Double(Latitude.text!)!,
            "country" : selectedType!
        ]
            print(parameters)
        Alamofire.request("https://bismarck.sdsu.edu/hometown/adduser", method: .post,
                          parameters: parameters, encoding: JSONEncoding.default)
            .validate()
            .responseString { response in
                switch response.result {
                case .success:
                    if let Response = response.result.value {
                        print(Response)
                        self.showToast(message: "User Added!")
                        self.clearForm()
                        
                    }
                case .failure(let error):
                    print(error)
                    self.showToast(message: "Error 400! Invalid Data Entered")
                }
        }
        }
    }
    
    func clearForm(){
        self.Nickname.text! = ""
        self.Password.text! = ""
        self.City.text! = ""
        self.Longitude.text! = "0.0"
        self.Latitude.text! = "0.0"
        self.Year.text! = ""
        self.selectedType  = self.CountryList?[0]
        self.StatesList = self.CountryAndStates[self.selectedType!]!.sorted()
        self.pickerView.reloadComponent(0)
        self.pickerView.selectRow(0, inComponent: 0, animated: true)
        self.pickerView.reloadComponent(1)
        self.pickerView.selectRow(0, inComponent: 1, animated: true)
    }
    
    func geoCode(address : String,completionHandler :((Bool)     -> Void)!){
        let locator = CLGeocoder()
        locator.geocodeAddressString(address)
        { (placemarks, errors) in
            if let place = placemarks?[0] {
                print("location : " ,place.location!)
                let lat = place.location!.coordinate.latitude
                let long = place.location!.coordinate.longitude
                self.Latitude.text = String(lat)
                self.Longitude.text = String(long)
                completionHandler(true)
            } else {
                print( errors! )
                completionHandler(false)
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.destination is LocationViewController
        {
            let vc = segue.destination as? LocationViewController
            vc?.Longitude = Double(self.Longitude.text!)!
            vc?.Latitude = Double(self.Latitude.text!)!
            vc?.delegate = self
            print(vc!.Longitude)
            print(vc!.Latitude)
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        reloadInputViews()
    }
    
    func getCountries(url:String, completionHandler :((Bool)     -> Void)!){
        
        Alamofire.request(url)
            .response(
                queue: self.queue,
                responseSerializer: DataRequest.jsonResponseSerializer(),
                completionHandler: { response in
                    if let JSON = response.data {
                        print("JSON: \(JSON)")
                    }
                    self.CountryList = response.result.value as? Array<String>
                    self.getStates(completionHandler : {(success) -> Void in
                        if success{
                            self.selectedType = self.CountryList![0]
                            self.StatesList = self.CountryAndStates[self.selectedType!]!
                            
                        }
                    })
                    completionHandler(true)
            }
        )
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.pickerView.delegate = self
        self.pickerView.dataSource = self
        self.Nickname.delegate = self
        self.Password.delegate = self
        self.City.delegate = self
        self.Year.delegate = self
        self.Latitude.delegate = self
        self.Longitude.delegate=self
        self.Latitude.text = "0.00"
        self.Longitude.text="0.00"
        submitButton.isEnabled = false
        self.getCountries(url: "https://bismarck.sdsu.edu/hometown/countries", completionHandler : {(success) -> Void in
            if success{
                print(self.CountryAndStates)
            }
        })
        
        ErrorMessage.isHidden = true
    }
    
    func getStates(completionHandler :((Bool)     -> Void)!){
        for i in 0...self.CountryList!.count-1{
            var List = Array<String>()
            Alamofire.request("https://bismarck.sdsu.edu/hometown/states?country="+self.CountryList![i])
                .response(
                    queue: self.queue,
                    responseSerializer: DataRequest.jsonResponseSerializer(),
                    completionHandler: { response in
                        List = (response.result.value as? Array<String>)!
                        self.CountryAndStates[self.CountryList![i]] = List
                        self.pickerView.reloadAllComponents()
                        completionHandler(true)
                }
            )
        }
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        guard (CountryList != nil) && StatesList != nil else { return 0 }
        switch component {
        case 0: return CountryList!.count
        case 1: return StatesList!.count
        default: return 0
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        guard (CountryList != nil) && StatesList != nil else { return "None" }
        switch component {
        case 0: return CountryList![row]
        case 1: return StatesList![row]
        default: return "None"
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        guard (CountryList != nil) && StatesList != nil else { return }
        if component == 0 {
            selectedType = CountryList![row]
            StatesList = CountryAndStates[selectedType!]!.sorted()
            pickerView.reloadComponent(1)
            pickerView.selectRow(0, inComponent: 1, animated: true)
        }
        selectedRow = row
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func validate(_ textField: UITextField) -> (Bool, String?) {
        guard let text = textField.text else {
            return (false, nil)
        }
        switch textField {
        case Password:
            return (text.count >= 3, "Your password is too short.")
        case Nickname :
             return (text.count > 0, "Nickname cannot be empty.")
        case City :
             return (text.count > 0, "City cannot be empty.")
        case Year :
            let year = Int(text)
            if year == nil{
                return (false,"Year should be bewteen 1970 and 2017")
            }
            else if year! < 1970 || year! > 2017{
                return (false,"Year should be bewteen 1970 and 2017")
            }
            else{
                return (true,"Year should be bewteen 1970 and 2017")
            }
        case Longitude :
            let long = Double(text)
            if long == nil{
                return (false,"Longitude should be bewteen -90 and 90")
            }
            else if long! < -90 || long! > 90{
                return (false,"Longitude should be bewteen -90 and 90")
            }
            else{
                return (true,"Longitude should be bewteen -90 and 90")
            }
        case Latitude :
            let lat = Double(text)
            if lat == nil{
                return (false,"Latitude should be bewteen -90 and 90")
            }
            else if lat! < -90 || lat! > 90{
                return (false,"Latitude should be bewteen -90 and 90")
            }
            else{
                return (true,"Latitude should be bewteen -90 and 90")
            }
        default:
            return (text.count > 0, "This field cannot be empty.")
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let (valid, res) = validate(textField)
        if valid == false{
            self.ErrorMessage.text = res!
            UIView.animate(withDuration: 0.25, animations: {
                self.ErrorMessage.isHidden = valid
            })
        }
        print("form is valid ",valid )
        submitButton.isEnabled = valid
        self.view.endEditing(true)
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        let (valid, res) = validate(textField)
        if valid == false{
            self.ErrorMessage.text = res!
            self.ErrorMessage.textColor =  UIColor.red
            UIView.animate(withDuration: 0.25, animations: {
                self.ErrorMessage.isHidden = valid
            })
        }
        else{
        print("form is valid ",valid )
        submitButton.isEnabled = valid
        self.view.endEditing(true)
        self.ErrorMessage.isHidden = true
        }
    }
}

