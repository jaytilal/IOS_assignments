//
//  LocationViewController.swift
//  assignment5
//
//  Created by Jayti Lal on 11/8/17.
//  Copyright © 2017 Jayti Lal. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

protocol SendDataToFormProtocol : class {
    func SendDataToForm(Longitude: Double, Latitude : Double)
}
extension UIViewController {
    func performSegueToReturnBack()  {
        if let nav = self.navigationController {
            nav.popViewController(animated: true)
        } else {
            self.dismiss(animated: true, completion: nil)
        }
    }
}


class LocationViewController: UIViewController,CLLocationManagerDelegate,MKMapViewDelegate {
    var Longitude : Double = 0
    var Latitude : Double = 0
    let newPin = MKPointAnnotation()
    weak var delegate : SendDataToFormProtocol?
    @IBOutlet weak var mapView: MKMapView!
    var locationManager:CLLocationManager!
    @IBAction func Cancel(_ sender: UIButton) {
        delegate?.SendDataToForm(Longitude: 0.0, Latitude: 0.0)
        self.performSegueToReturnBack()
    }
   
    @IBAction func SetLocation(_ sender: UIButton) {
        delegate?.SendDataToForm(Longitude: Longitude, Latitude: Latitude)
        self.performSegueToReturnBack()
    }
    
    func determineCurrentLocation()
    {
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        let location = locationManager.location
        
        if location == nil{
            newPin.coordinate = CLLocationCoordinate2D(latitude: 32.7157, longitude: -117.1611)
        }
        else{
            newPin.coordinate = (location?.coordinate)!
        }
        newPin.title = "Current Location"
        mapView.addAnnotation(newPin)
        if CLLocationManager.locationServicesEnabled() {
            locationManager.startUpdatingLocation()
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        if Longitude==0 && Latitude==0{
            determineCurrentLocation()
        }
        let coordinate = CLLocationCoordinate2D(latitude: Latitude, longitude: Longitude)
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        annotation.title = "You are here"
        self.mapView.addAnnotation(annotation)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error)
    {
        print("Error \(error)")
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let annotations = self.mapView.annotations
            for _annotation in annotations {
                 self.mapView.removeAnnotation(_annotation)
                
            }
            let touchPoint = touch.location(in: self.mapView)
            let location = self.mapView.convert(touchPoint, toCoordinateFrom: self.mapView)
            print ("\(location.latitude), \(location.longitude)")
            Latitude = location.latitude
            Longitude = location.longitude
            let coordinate = CLLocationCoordinate2D(latitude: Latitude, longitude: Longitude)
            let annotation = MKPointAnnotation()
            annotation.coordinate = coordinate
            annotation.title = "You are here"
            self.mapView.addAnnotation(annotation)
        }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        _ = locations.last
        
    }

}
