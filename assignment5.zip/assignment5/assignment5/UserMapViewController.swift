//
//  UserMapViewController.swift
//  assignment5
//
//  Created by Jayti Lal on 11/7/17.
//  Copyright © 2017 Jayti Lal. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Alamofire


class UserMapViewController: UIViewController,UIPickerViewDataSource, UIPickerViewDelegate {
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var CountryPicker: UIPickerView!
    @IBOutlet weak var Year: UITextField!
    
    var selectedType = "Select Country"
    var selectedRow : Int = 0
    var CountryList = Array<String>()
    var UserList = Array<User>()
    var SearchList = Array<User>()
    
    var locationManager:CLLocationManager = CLLocationManager()
    
    @IBAction func Search(_ sender: UIButton) {
        let annotations = self.mapView.annotations
        for _annotation in annotations {
            self.mapView.removeAnnotation(_annotation)
        }
        if selectedType == "Select Country" &&  Year.text == "" {
            self.getSearchResults(url: "https://bismarck.sdsu.edu/hometown/users");
        }
        
        if (Year.text == "" ) && (selectedType != "Select Country"){
            self.getSearchResults(url: "http://bismarck.sdsu.edu/hometown/users?country=" + selectedType)
        }
        if (Year.text != "" ) && (selectedType != "Select Country"){
            self.getSearchResults(url: "https://bismarck.sdsu.edu/hometown/users?country=" + selectedType + "&year=" + Year.text!)
        }
        if (Year.text != "" ) && selectedType == "Select Country" {
            self.getSearchResults(url: "https://bismarck.sdsu.edu/hometown/users?year=" + Year.text!)
        }
        self.mapView.reloadInputViews()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getCountries()
        locationManager.requestWhenInUseAuthorization()
        mapView!.mapType = MKMapType.standard
        mapView!.showsUserLocation = true
        mapView!.showsTraffic = true
        getUsers()
        self.CountryPicker.delegate = self
        self.CountryPicker.dataSource = self
    }
    
    func getUsers(){
        Alamofire.request("https://bismarck.sdsu.edu/hometown/users")
            .validate()
            .responseJSON { response in
                switch response.result {
                case .success:
                    if let Response = response.result.value {
                        let res = Response as! NSArray
                        for i in 0...res.count-1{
                            let jsonDictionary = res[i] as! NSDictionary
                            let user = User()
                            user.city = jsonDictionary["city"] as! String
                            user.country = jsonDictionary["country"] as! String
                            user.latitude = jsonDictionary["latitude"] as! Double
                            user.longitude = jsonDictionary["longitude"] as! Double
                            user.nickname = jsonDictionary["nickname"] as! String
                            user.state = jsonDictionary["state"] as! String
                            user.year = jsonDictionary["year"] as! Int
                            self.UserList.append(user)
                            self.addPin(user: user)
                        }
                        print(self.UserList.count)
                        
                    }
                case .failure(let error):
                    print(error)
                }
        }
    }
    
    func getCountries(){
        var array = Array<String>()
        self.CountryList.append("Select Country")
        Alamofire.request("https://bismarck.sdsu.edu/hometown/countries")
            .responseJSON{ response in
                if response.data != nil {
                    print("JSON: \(String(describing: response.result.value))")
                    array = (response.result.value as? Array<String>)!
                    for i in array{
                        self.CountryList.append(i)
                    }
                    
                    print(self.CountryList)
                    self.CountryPicker.reloadComponent(0)
                }
        }
    }
    
    func getSearchResults(url : String){
        Alamofire.request(url)
            .validate()
            .responseJSON { response in
                switch response.result {
                case .success:
                    if let Response = response.result.value {
                        self.SearchList = [User]()
                        let res = Response as! NSArray
                        if res.count > 0{
                            for i in 0...res.count-1{
                                let jsonDictionary = res[i] as! NSDictionary
                                let user = User()
                                user.city = jsonDictionary["city"] as! String
                                user.country = jsonDictionary["country"] as! String
                                user.latitude = jsonDictionary["latitude"] as! Double
                                user.longitude = jsonDictionary["longitude"] as! Double
                                user.nickname = jsonDictionary["nickname"] as! String
                                user.state = jsonDictionary["state"] as! String
                                user.year = jsonDictionary["year"] as! Int
                                self.SearchList.append(user)
                            }
                            print(self.SearchList.count)
                        }
                        if self.SearchList.count != 0{
                            for i in 0...self.SearchList.count-1{
                                self.mapView.reloadInputViews()
                                self.addPin(user: self.SearchList[i])
                            }
                        }
                    }
                case .failure(let error):
                    print(error)
                }
        }
    }
    
    
    func addPin(user : User){
        let coordinate = CLLocationCoordinate2D(latitude: user.latitude, longitude: user.longitude)
        print(user.nickname)
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        annotation.title = user.nickname
        annotation.subtitle = user.nickname
        self.mapView.addAnnotation(annotation)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return CountryList.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return CountryList[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        guard (CountryList.count != 0) else { return }
        if component == 0 {
            selectedType = CountryList[row]
        }
        selectedRow = row
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}
