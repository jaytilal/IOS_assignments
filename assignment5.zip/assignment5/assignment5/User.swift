//
//  User.swift
//  assignment5
//
//  Created by Jayti Lal on 11/9/17.
//  Copyright © 2017 Jayti Lal. All rights reserved.
//

import Foundation

class User {
    var nickname : String = ""
    var password : String = ""
    var country : String = ""
    var state : String = ""
    var city : String = ""
    var latitude : Double = 0
    var longitude : Double = 0
    var year : Int = 0
    
    
}
