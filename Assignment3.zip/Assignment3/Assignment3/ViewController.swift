//
//  ViewController.swift
//  Assignment3
//
//  Created by Jayti Lal on 10/6/17.
//  Copyright © 2017 Jayti Lal. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate{
    
    @IBOutlet weak var blueValue: UITextField!
    @IBOutlet weak var greenValue: UITextField!
    @IBOutlet weak var redValue: UITextField!
    @IBOutlet weak var colorView: UIView!
    
    @IBOutlet weak var redSlider: UISlider!
    @IBOutlet weak var blueSlider: UISlider!
    @IBOutlet weak var greenSlider: UISlider!
    
    @IBAction func changeViewBackground(_ sender: Any) {
        
        var red = Float(redValue.text!)
        if red != nil{
            red = Float(redValue.text!)!
        }
        else{
            red = 0
            redValue.text = "0"
        }
        var blue = Float(blueValue.text!)
        if blue != nil{
            blue = Float(blueValue.text!)!
        }
        else{
            blue = 0
            blueValue.text = "0"
        }
        var green = Float(greenValue.text!)
        if green != nil{
            green = Float(greenValue.text!)!
        }
        else{
            green = 0
            greenValue.text = "0"
        }
        if red != nil && blue != nil && green != nil {
            self.colorView.backgroundColor = UIColor(red!,green!,blue!)
        }
        
        self.view.endEditing(true)
        
        let redVal = redValue.text;
        let defaults = UserDefaults.standard
        defaults.set(redVal, forKey: "redVal")
        let blueVal = blueValue.text;
        defaults.set(blueVal, forKey: "blueVal")
        let greenVal = greenValue.text;
        defaults.set(greenVal, forKey: "greenVal")
        
    }
    
    func setColor(_ r: Float,_ g:Float,_ b:Float){
        colorView.backgroundColor = UIColor(r,g,b)
        let redVal = redValue.text;
        let defaults = UserDefaults.standard
        defaults.set(redVal, forKey: "redVal")
        let blueVal = blueValue.text;
        defaults.set(blueVal, forKey: "blueVal")
        let greenVal = greenValue.text;
        defaults.set(greenVal, forKey: "greenVal")
    }
    
    @IBAction func redValueChanged(_ sender: UISlider) {
        self.view.endEditing(true)
        let redVal = Float(sender.value)
        redValue.text = String(redVal)
        setColor(redVal,greenSlider.value,blueSlider.value)
    }
    @IBAction func greenValueChanged(_ sender: UISlider) {
        self.view.endEditing(true)
        let greenVal = Float(sender.value)
        greenValue.text = String(greenVal)
        setColor(redSlider.value,greenVal,blueSlider.value)
    }
    
    @IBAction func blueValueChanged(_ sender: UISlider) {
        self.view.endEditing(true)
        let blueVal = Float(sender.value)
        blueValue.text = String(blueVal)
        setColor(redSlider.value,greenSlider.value,blueVal)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let defaults = UserDefaults.standard
        blueValue.text = defaults.string(forKey: "blueVal")
        greenValue.text = defaults.string(forKey: "greenVal")
        redValue.text = defaults.string(forKey: "redVal")
        
        setColor(Float(redValue.text!)!,Float(greenValue.text!)!,Float(blueValue.text!)!)
        
        blueValue.delegate = self
        redValue.delegate = self
        greenValue.delegate = self
        
        redSlider.minimumValue = 0
        redSlider.maximumValue = 100
        redSlider.value = Float(redValue.text!)!
        
        blueSlider.minimumValue = 0
        blueSlider.maximumValue = 100
        blueSlider.value = Float(blueValue.text!)!
        
        greenSlider.minimumValue = 0
        greenSlider.maximumValue = 100
        greenSlider.value = Float(greenValue.text!)!
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        switch textField {
        case redValue:
             if Float(redValue.text!) != nil{
                if Float(redValue.text!)! < 0{
                    redValue.text = "0"
                }
                else if Float(redValue.text!)! > 100{
                    redValue.text = "100"
                }
            }
            else{
                redValue.text = "0"
            }
            redSlider.value = Float(redValue.text!)!

        case blueValue:
            if Float(blueValue.text!) != nil{
                if Float(blueValue.text!)! < 0{
                    blueValue.text = "0"
                }
                else if Float(blueValue.text!)! > 100{
                    blueValue.text = "100"
                }
            }
            else{
                blueValue.text = "0"
            }
            blueSlider.value = Float(blueValue.text!)!
            
        case greenValue:
            if Float(greenValue.text!) != nil{
                if Float(greenValue.text!)! < 0{
                    greenValue.text = "0"
                }
                else if Float(greenValue.text!)! > 100{
                    greenValue.text = "100"
                }
            }
            else{
                greenValue.text = "0"
            }
            greenSlider.value = Float(greenValue.text!)!
            
        default:
            textField.text =
            "0"
        }
    }
}
extension UIColor {
    convenience init(_ r: Float,_ g: Float,_ b: Float) {
        self.init(red:CGFloat(r)/100 , green: CGFloat(g)/100, blue: CGFloat(b)/100,alpha:1.0)
    }
}
