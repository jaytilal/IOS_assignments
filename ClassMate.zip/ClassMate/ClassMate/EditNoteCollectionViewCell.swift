//
//  EditNoteCollectionViewCell.swift
//  ClassMate
//
//  Created by Jayti Lal on 12/12/17.
//  Copyright © 2017 Jayti Lal. All rights reserved.
//

import UIKit

class EditNoteCollectionViewCell: UICollectionViewCell {
    
}
