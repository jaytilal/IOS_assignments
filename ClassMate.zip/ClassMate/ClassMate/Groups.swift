//
//  Groups.swift
//  ClassMate
//
//  Created by Oshin Mundada on 12/12/17.
//  Copyright © 2017 Jayti Lal. All rights reserved.
//

import Foundation

struct Groups {
    let name : String
    let hashtags : String
}
