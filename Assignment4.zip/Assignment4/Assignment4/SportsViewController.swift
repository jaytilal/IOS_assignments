//
//  SportsViewController.swift
//  Assignment4
//
//  Created by Jayti Lal on 10/21/17.
//  Copyright © 2017 Jayti Lal. All rights reserved.
//

import UIKit

class SportsViewController: UIViewController,UIPickerViewDataSource, UIPickerViewDelegate {
    
    var CountryAndSports:Dictionary<String,Array<String>>?
    var CountryList:Array<String>?
    var SportsList:Array<String>?
    var selectedType:String?
    var selectedRow : Int = 0
    
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var SportSlider: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let data:Bundle = Bundle.main
        let dataList:String? = data.path(forResource: "SportsList", ofType: "plist")
        if dataList != nil{
            CountryAndSports = (NSDictionary.init(contentsOfFile: dataList!) as! Dictionary);
            CountryList = CountryAndSports?.keys.sorted()
            selectedType = CountryList![0]
            SportsList = CountryAndSports![selectedType!]!.sorted()
            self.pickerView.delegate = self
            self.pickerView.dataSource = self
            self.SportSlider.value = 0.0
        }
    }
    
    @IBAction func ChangeSport(_ sender: UISlider) {
        SportsList = CountryAndSports![selectedType!]!.sorted()
        let count = (SportsList?.count)!
        let row = Int((sender.value) * Float(count))
        pickerView.selectRow(row, inComponent: 1, animated: true)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        guard (CountryList != nil) && SportsList != nil else { return 0 }
        switch component {
        case 0: return CountryList!.count
        case 1: return SportsList!.count
        default: return 0
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        guard (CountryList != nil) && SportsList != nil else { return "None" }
        switch component {
        case 0: return CountryList![row]
        case 1: return SportsList![row]
        default: return "None"
        }
        
    }
    
    func setSlider(_ value : Int,_ total : Int){
        SportSlider.value = Float(Float (value) / Float(total-1))
        print(SportSlider.value)
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        guard (CountryList != nil) && SportsList != nil else { return }
        if component == 0 {
            selectedType = CountryList![row]
            SportsList = CountryAndSports![selectedType!]!.sorted()
            pickerView.reloadComponent(1)
            pickerView.selectRow(0, inComponent: 1, animated: true)
            setSlider(0, 0)
        }
        selectedRow = row
        if(component == 1){
            setSlider(row, (SportsList?.count)!)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
}

