//
//  ProgressViewController.swift
//  Assignment4
//
//  Created by Jayti Lal on 10/21/17.
//  Copyright © 2017 Jayti Lal. All rights reserved.
//

import UIKit

class ProgressViewController: UIViewController {
    
    @IBOutlet weak var ActivityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var Switch: UISwitch!
    
    @IBAction func switchStatus(_ sender: UISwitch) {
        switch sender.isOn{
        case true : ActivityIndicator.startAnimating()
        case false :
            ActivityIndicator.stopAnimating()
        }
    }
    
    @IBOutlet weak var switchStatusOutlet: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()
        switch switchStatusOutlet.isOn{
        case true : ActivityIndicator.startAnimating()
        case false :
            ActivityIndicator.stopAnimating()
        }

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
