//
//  SegmentViewController.swift
//  Assignment4
//
//  Created by Jayti Lal on 10/21/17.
//  Copyright © 2017 Jayti Lal. All rights reserved.
//

import UIKit

class SegmentViewController: UIViewController {

    @IBOutlet weak var textView: UIView!
    @IBOutlet weak var progressView: UIView!
    @IBOutlet weak var Segment: UISegmentedControl!
    @IBOutlet weak var alertView: UIView!
   
    
    @IBAction func showComponent(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0 :
                UIView.animate(withDuration: 0.2,  animations: {
                self.progressView.alpha = 1
                self.textView.alpha = 0
                self.alertView.alpha = 0
                self.view.endEditing(false)
                    
            })
        case 1:
                UIView.animate(withDuration: 0.2, animations: {
                self.progressView.alpha = 0
                self.textView.alpha = 1
                self.alertView.alpha = 0
                    self.view.endEditing(false)
                    
            })
        
        case 2:
                UIView.animate(withDuration: 0.2, animations: {
                self.progressView.alpha = 0
                self.textView.alpha = 0
                self.alertView.alpha = 1
                self.view.endEditing(false)
                    
        })
            
        default : break
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UIView.animate(withDuration: 0.0,  animations: {
            self.progressView.alpha = 1
            self.textView.alpha = 0
            self.alertView.alpha = 0
            self.view.backgroundColor = self.progressView.backgroundColor

        })
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    

}
